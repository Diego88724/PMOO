package ejemplosdebbug;

/**
 * @author Juli�n Guti�rrez
 * Material para el Laboratorio de PMOO. 
 */

import javax.swing.JOptionPane;

public class Ejemplo2 {

/**
 * Estamos escribiendo un m�todo que rellena un array poniendo en cada posici�n un entero 
 * que es el doble del �ndice m�s uno. Es decir, en un Arrray de 5 celdas podr�a: 2 4 6 8 10.
 * Luego escribe esas celdas.
 * @param args
 */
	
	public static void main(String[] args) {
		int elementos = Integer.parseInt(JOptionPane.showInputDialog("Introduce el n�mero de elementos de la tabla"));
		
		int tabla[]=new int[elementos];
		
		for(int i=0; i<tabla.length;i++) {
			tabla[i]= i++ *2;
		
		}
		for(int i=0; i<tabla.length;i++) {

			System.out.println(tabla[i]);
		}

	}
}

