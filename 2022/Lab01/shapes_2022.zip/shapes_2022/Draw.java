
/**
 * Write a description of class Draw here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Draw
{
       
    /**
     * Write instructions for exercise 6b
     */
    public  void triangleMiddle()
    {
        //Define variables, objects and instructions
    }
      
    /**
     * Write instructions for exercise 6e
     */
    public void squareCorner()
    {
        //Define variables, objects and instructions
    }   
    

   
}
