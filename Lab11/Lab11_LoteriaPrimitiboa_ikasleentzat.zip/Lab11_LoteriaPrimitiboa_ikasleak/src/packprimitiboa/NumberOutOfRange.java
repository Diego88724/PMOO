package packprimitiboa;
/**
 * Write a description of class NumberOutOfRangeOfException here.
 * 
 * @author Ainhoa Alvarez 
 * @author Olatz Ansa
 * @version 2022-04-26
 */
 @SuppressWarnings("serial")
 public class NumberOutOfRange extends Exception {
     public NumberOutOfRange(String s) {
           super(s);
     }
 }
